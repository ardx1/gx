﻿<?php

//Regards
date_default_timezone_set('America/Toronto');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "postal.thatsuitemoney.net",
        "port"     => "25",
        "username" => "that-suite-money/that-suite-money",
        "password" => "ohe0ipDhswis5LkQUgmL1bua"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 1,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/hot.txt",
    "fromname"       => "decision@thatsuitemoney.net",
    "frommail"       => "decision@thatsuitemoney.net",
    "subject"        => "Canadian Microsoft Settlement / Règlement canadien Microsoft - DECISION - 105525",
    "msgfile"        => "file/letter/letter.html",
    "filepdf"        => "",
    "scampage"       => [""],
];
